package mvc.Dao;

import mvc.model.pojo_address;
import mvc.model.pojo_image;
import mvc.model.pojo_registration;

public interface Daoinsertinterface {
	public void insert_registration(pojo_registration register);
	public void insert_address(pojo_address address[]);
	public void insert_image(pojo_image image);
}
