package mvc.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import mvc.model.pojo_registration;
import mvc.util.dbconnection;

public class Daodelete implements Daodeleteinterface {

		dbconnection connect = new dbconnection();
	
	public void deleteuserdata(pojo_registration register){
		try {
			Class.forName(connect.driverconnection());
			Connection con = DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());
			String query="delete from user_registration where rid='"+register.getRid()+"'";
			PreparedStatement ps = con.prepareStatement(query);
			ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void delete_image(int image_id) {
		// TODO Auto-generated method stub
		try {
			Class.forName(connect.driverconnection());
			Connection con = DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());
			PreparedStatement ps = con.prepareStatement("delete from image where image_id=?");
			ps.setInt(1, image_id);
			ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
