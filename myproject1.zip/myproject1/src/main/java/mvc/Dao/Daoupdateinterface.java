package mvc.Dao;

import mvc.model.pojo_address;
import mvc.model.pojo_image;
import mvc.model.pojo_registration;

public interface Daoupdateinterface {
	
	public void updateregisterdata(pojo_registration register);
	public void updateaddressdata(pojo_address paddress[]);
	public void updatepassword(pojo_registration register);
	public void forgetpassword(pojo_registration register);
	public void update_image(pojo_image image);
}
