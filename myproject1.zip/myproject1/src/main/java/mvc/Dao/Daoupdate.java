package mvc.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import mvc.model.pojo_address;
import mvc.model.pojo_image;
import mvc.model.pojo_registration;
import mvc.util.dbconnection;

public class Daoupdate implements Daoupdateinterface {

	dbconnection connect = new dbconnection();
	
	public void updateregisterdata(pojo_registration register) {
		// TODO Auto-generated method stub
		
		try {
			Class.forName(connect.driverconnection());
			Connection con = DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());

			PreparedStatement ps = con.prepareStatement("update user_registration set fname=?,lname=?,dob=?,contact=?,hobby_name=?,tech_name=?,lang_name=?,gender=? where rid=?");
			ps.setString(1, register.getFname());
			ps.setString(2,register.getLname());
			ps.setString(3, register.getDob());
			ps.setString(4, register.getContact());
			ps.setString(5, register.getHobby_name());
			ps.setString(6, register.getTech_name());
			ps.setString(7, register.getLang_name());
			ps.setString(8, register.getGender());
			ps.setInt(9, register.getRid());
			ps.executeUpdate();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

	public void updateaddressdata(pojo_address[] paddress) {
		// TODO Auto-generated method stub
		
		try {

			Class.forName(connect.driverconnection());
			Connection con = DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());
			String query="update address set address=?, city=?, state=?, country=? where add_id=?";
			PreparedStatement ps = con.prepareStatement(query);
			for(int i=0;i<paddress.length;i++){
				ps.setString(1, paddress[i].getAddress());
				ps.setString(2, paddress[i].getCity());
				ps.setString(3, paddress[i].getState());
				ps.setString(4, paddress[i].getCountry());
				ps.setInt(5, paddress[i].getAdd_id());
				ps.addBatch();

			}
			ps.executeBatch();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		}

		
	}

	public void updatepassword(pojo_registration register) {
		// TODO Auto-generated method stub
		try {
			Class.forName(connect.driverconnection());
			System.out.println(register.getRid());
			System.out.println(register.getPassword());
			Connection con = DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());
			String query="update user_registration set password='"+register.getPassword()+"' where rid='"+register.getRid()+"'";
			PreparedStatement ps = con.prepareStatement(query);

			ps.executeUpdate();
		} 
		catch(Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public void forgetpassword(pojo_registration register) {
		// TODO Auto-generated method stub
		try {
			Class.forName(connect.driverconnection());
			String query="update user_registration set password='"+register.getPassword()+"' where email='"+register.getEmail()+"'";
			Connection con = DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());
			PreparedStatement ps = con.prepareStatement(query);
			ps.executeUpdate();
		
			} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void update_image(pojo_image image) {
		// TODO Auto-generated method stub
			try{
				Class.forName(connect.driverconnection());
				Connection con = (Connection) DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());
				PreparedStatement psmt = (PreparedStatement) con.prepareStatement("update image set image_name='"+image.getImage_name()+"',image='"+image.getImage()+"' where image_id='"+image.getImage_id()+"'");
				/*psmt.setString(1, image.getImage_name());
				psmt.setBlob(2, image.getImage());
				psmt.setInt(3,image.getImage_id());*/
				psmt.executeUpdate();
			}catch(Exception e){
				System.out.println(e.getMessage());
		}
		
	}

}
