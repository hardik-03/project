package mvc.Dao;

import java.util.ArrayList;

import javax.servlet.http.HttpServletResponse;

import mvc.model.pojo_address;
import mvc.model.pojo_image;
import mvc.model.pojo_registration;

public interface Daoselectinterface {

	public pojo_registration singleuserregdata(pojo_registration register);
	public ArrayList<pojo_address> singleuseradresdata(int rid);
	public ArrayList<pojo_registration> selectalluserregdata(ArrayList<pojo_registration> arraylist);
	public ArrayList<pojo_address> selectalluseradresdata(ArrayList arraylist);
	public int selectuserid();
	public pojo_registration selectlogindata(pojo_registration register);
	public ArrayList<pojo_image> selectallimagename(pojo_image image);
	public void select_single_image(pojo_image image, HttpServletResponse response);
	public int select_email(String email);
}
