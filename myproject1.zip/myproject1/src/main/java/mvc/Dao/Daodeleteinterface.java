package mvc.Dao;

import mvc.model.pojo_registration;

public interface Daodeleteinterface {

	public void deleteuserdata(pojo_registration register);
	public void delete_image(int image_id);
}
