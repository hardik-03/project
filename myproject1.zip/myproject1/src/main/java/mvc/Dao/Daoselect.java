package mvc.Dao;

import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import mvc.model.pojo_address;
import mvc.model.pojo_image;
import mvc.model.pojo_registration;
import mvc.util.dbconnection;

public class Daoselect implements Daoselectinterface {

	dbconnection connect = new dbconnection();
	
	public pojo_registration singleuserregdata(pojo_registration register) {
		// TODO Auto-generated method stub
		try {
			List datalist = new ArrayList();
			Class.forName(connect.driverconnection());
			Connection con = DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());

			Statement stmt = con.createStatement();
			String query="select fname,lname,email,dob,contact,hobby_name,tech_name,lang_name,gender from user_registration where rid='"+register.getRid()+"'";
			ResultSet rs = stmt.executeQuery(query);

			while(rs.next()) {


				register.setFname(rs.getString("fname"));
				register.setLname(rs.getString("lname"));
				register.setEmail(rs.getString("email"));
				register.setDob(rs.getString("dob"));
				register.setContact(rs.getString("contact"));
				register.setHobby_name(rs.getString("hobby_name"));
				register.setTech_name(rs.getString("tech_name"));
				register.setLang_name(rs.getString("lang_name"));
				register.setGender(rs.getString("gender"));
				datalist.add(register);

			}


		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}

		
		return register;
	}

	public ArrayList<pojo_address> singleuseradresdata(int rid) {
		// TODO Auto-generated method stub
		ArrayList<pojo_address> arraylist = new ArrayList<pojo_address>();
		try {
			new pojo_address();
			Class.forName(connect.driverconnection());
			Connection con=DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());
			String query="select add_id,address,city,state,country from address where rid='"+rid+"'";
			Statement stmt=con.createStatement();
			ResultSet rs = stmt.executeQuery(query);

			while(rs.next()){
				pojo_address address1 = new pojo_address();
				address1.setAdd_id(rs.getInt("add_id"));
				address1.setAddress(rs.getString("address"));
				address1.setCity(rs.getString("city"));
				address1.setState(rs.getString("state"));
				address1.setCountry(rs.getString("country"));
				arraylist.add(address1);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.print(e.getMessage());
		}

		return arraylist;
	}

	public ArrayList<pojo_registration> selectalluserregdata(ArrayList<pojo_registration> arraylist) {
		// TODO Auto-generated method stub
		try {
			pojo_registration register;
			Class.forName(connect.driverconnection());
			Connection con = DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());
			String query="select * from user_registration where role_id=2";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while(rs.next()){
				register=new pojo_registration();
				register.setRid(rs.getInt("rid"));
				register.setFname(rs.getString("fname"));
				register.setLname(rs.getString("lname"));
				register.setEmail(rs.getString("email"));
				register.setDob(rs.getString("dob"));
				register.setContact(rs.getString("contact"));
				register.setHobby_name(rs.getString("hobby_name"));
				register.setTech_name(rs.getString("tech_name"));
				register.setLang_name(rs.getString("lang_name"));
				register.setGender(rs.getString("gender"));
				arraylist.add(register);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		return arraylist;
	}

	public ArrayList<pojo_address> selectalluseradresdata(ArrayList arraylist) {
		// TODO Auto-generated method stub
		try {
			pojo_address paddress = new pojo_address();
			Class.forName(connect.driverconnection());
			Connection con=DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());
			String query="select add_id,address,city,state,country from address";
			Statement stmt=con.createStatement();
			ResultSet rs = stmt.executeQuery(query);

			while(rs.next()){
				paddress.setAdd_id(rs.getInt("add_id"));
				paddress.setAddress(rs.getString("address"));
				paddress.setCity(rs.getString("city"));
				paddress.setState(rs.getString("state"));
				paddress.setCountry(rs.getString("country"));
				arraylist.add(paddress);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.print(e.getMessage());
		}
		
		return arraylist;
	}

	public int selectuserid() {
		// TODO Auto-generated method stub
		int user_id=0;
		try {
			
			Class.forName(connect.driverconnection());
			Connection con =  DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());
			Statement stmt = con.createStatement();
			String query="select MAX(rid) from user_registration";
			ResultSet rs = stmt.executeQuery(query);
			while(rs.next()) {
				user_id=rs.getInt("MAX(rid)");
				System.out.println("rid is from select"+user_id);
			}
			if(rs.getInt(user_id)==0) {
				user_id=0;
			}
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}

		return user_id;
	}

	public pojo_registration selectlogindata(pojo_registration register) {
		// TODO Auto-generated method stub
		//ArrayList<pojo_registration> arraylist = new ArrayList<pojo_registration>();
		try{
		Class.forName(connect.driverconnection());
		Connection con = DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());
		//String query = "select email,password,role_id,rid from user_registration where email='"+register.getEmail()+"' and pass='"+register.getPassword()+"'";
		//Statement stmt = con.createStatement();
		PreparedStatement psmt = con.prepareStatement("select email,password,role_id,rid from user_registration where email=? and password=? ");
		psmt.setString(1, register.getEmail());
		psmt.setString(2, register.getPassword());
		ResultSet rs = psmt.executeQuery();
		
			while(rs.next()){
				register.setRid(rs.getInt("rid"));
				register.setRole_id(rs.getInt("role_id"));
				register.setEmail(rs.getString("email"));
				register.setPassword(rs.getString("password"));
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return register;
	}

	public ArrayList<pojo_image> selectallimagename(pojo_image image) {
		// TODO Auto-generated method stub
		ArrayList<pojo_image> arraylist = new ArrayList<pojo_image>();
		 
		try{
			Class.forName(connect.driverconnection());
			Connection con = DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());
			PreparedStatement psmt = con.prepareStatement("select image_id,image_name from image where user_id=?");
			psmt.setInt(1, image.getUser_id());
			ResultSet rs = psmt.executeQuery();
			while(rs.next()){
				pojo_image image1 = new pojo_image();
				image1.setImage_name(rs.getString("image_name"));
				image1.setImage_id(rs.getInt("image_id"));
				arraylist.add(image1);
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return arraylist;
	}

	public void select_single_image(pojo_image image, HttpServletResponse response) {
		// TODO Auto-generated method stub
		//byte bytearray[] = new byte[1048576];
		try{
			InputStream input = null;
			Class.forName(connect.driverconnection());
			Connection con = DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());
			PreparedStatement psmt = con.prepareStatement("select image_id,image from image where image_id=?");
			System.out.println("image_id"+image.getImage_id());
			psmt.setInt(1, image.getImage_id());
			ResultSet rs = psmt.executeQuery();
			while(rs.next()){
				/*int size=0;
				System.out.println("input"+input);
				input=rs.getBinaryStream("image");
				System.out.println("input is"+input);
				response.reset();
				response.setContentType("image/jpg");
				while((size = input.read(bytearray)) != -1 ){
                    response.getOutputStream().
                    write(bytearray,0,size);
                }*/
				Blob blob = (Blob)rs.getBlob("image");
				byte bytearray[]=blob.getBytes(1, (int)blob.length()); 
		        response.setContentType("image/jpg");
		        OutputStream os = response.getOutputStream();
		        os.write(bytearray);
		        os.flush();
		        os.close();
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

	public int select_email(String email) {
		// TODO Auto-generated method stub
		int row=0;
		try{
			Class.forName(connect.driverconnection());
			Connection con = DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());
			PreparedStatement psmt = con.prepareStatement("select email from user_registration where email=?");
			psmt.setString(1, email);
			ResultSet rs = psmt.executeQuery();
			while(rs.next()){
				row=1;
				
			}
			
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return row;
	}
	
	

}
