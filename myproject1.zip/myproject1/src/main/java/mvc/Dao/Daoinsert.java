package mvc.Dao;

import java.sql.DriverManager;

import mvc.model.pojo_address;
import mvc.model.pojo_image;
import mvc.model.pojo_registration;
import mvc.util.dbconnection;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class Daoinsert implements Daoinsertinterface{
	dbconnection connect= new dbconnection();
	PreparedStatement ps=null;
	public void insert_registration(pojo_registration register) {
		// TODO Auto-generated method stub
		try {
			Class.forName(connect.driverconnection());
			Connection con =  (Connection) DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());
			ps = (PreparedStatement) con.prepareStatement("insert into user_registration(fname,lname,email,password,dob,contact,hobby_name,tech_name,lang_name,role_id,gender) values(?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1,register.getFname());
			ps.setString(2, register.getLname());
			ps.setString(3, register.getEmail());
			ps.setString(4, register.getPassword());
			ps.setString(5, register.getDob());
			ps.setString(6, register.getContact());
			ps.setString(7, register.getHobby_name());
			ps.setString(8, register.getTech_name());
			ps.setString(9, register.getLang_name());
			ps.setInt(10, register.getRole_id());
			ps.setString(11, register.getGender());
			ps.executeUpdate();
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
	}

	public void insert_address(pojo_address[] address) {
		// TODO Auto-generated method stub
		
		try {
			
			Class.forName(connect.driverconnection());
			Connection con = (Connection) DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());
			con.setAutoCommit(false);
			ps = (PreparedStatement) con.prepareStatement("insert into address(address,city,state,country,rid) values(?,?,?,?,?)");
			for(int i=0;i<address.length;i++){
			ps.setString(1, address[i].getAddress());
			ps.setString(2, address[i].getCity());
			ps.setString(3, address[i].getState());
			ps.setString(4, address[i].getCountry());
			ps.setInt(5, address[i].getRid());
			ps.addBatch();
			}
			ps.executeBatch();
			con.commit();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

	public void insert_image(pojo_image image) {
		// TODO Auto-generated method stub
		try{
			Class.forName(connect.driverconnection());
			Connection con = (Connection) DriverManager.getConnection(connect.connectionurl(),connect.connectionuser(),connect.connectionpass());
			PreparedStatement psmt = (PreparedStatement) con.prepareStatement("insert into image(image,user_id,image_name) values(?,?,?)");
			psmt.setBlob(1, image.getImage());
			psmt.setInt(2, image.getUser_id());
			psmt.setString(3,image.getImage_name());
			psmt.executeUpdate();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		
	}

}
