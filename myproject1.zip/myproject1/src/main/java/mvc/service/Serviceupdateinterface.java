package mvc.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Part;

public interface Serviceupdateinterface {
	
	public void updateuserprofile(HttpServletRequest request);
	public void update_password(int rid,String new_pass,HttpServletRequest request );
	public void forget_password(String email,String pass);
	public void updateimage(String image_name,Part part,int image_id);
}
