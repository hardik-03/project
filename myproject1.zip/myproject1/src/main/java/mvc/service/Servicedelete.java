package mvc.service;

import mvc.Dao.Daodelete;
import mvc.Dao.Daodeleteinterface;
import mvc.model.pojo_registration;

public class Servicedelete implements Servicedeleteinterface {
	pojo_registration register= new pojo_registration();
	Daodeleteinterface delete = new Daodelete();
	public void deleteuser(int rid) {
		// TODO Auto-generated method stub
		register.setRid(rid);
		delete.deleteuserdata(register);
	}
	public void deleteimage(int image_id) {
		// TODO Auto-generated method stub
		delete.delete_image(image_id);
	}

}
