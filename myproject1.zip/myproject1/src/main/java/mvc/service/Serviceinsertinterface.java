package mvc.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Part;

public interface Serviceinsertinterface {
	public void insertregistration(ArrayList arraylist);
	public void insertaddress(HttpServletRequest request);
	public void insertimage(String name,Part part,int user_id);
}
