package mvc.service;

public interface Servicedeleteinterface {
	public void deleteuser(int rid);
	public void deleteimage(int image_id);
}
