package mvc.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.model.pojo_address;
import mvc.model.pojo_image;
import mvc.model.pojo_registration;

public interface Serviceselectinterface {

	public pojo_registration selectsingleregdata(int rid);
	public ArrayList<pojo_address> selectsingleadresdata(int rid);
	public ArrayList<pojo_registration> alluserregdata();
	public ArrayList<pojo_address> alluseradresdata();
	public int selectuser_id();
	public pojo_registration selectlogin(String email, String pass);
	public ArrayList<pojo_image> selectimagename(int user_id);
	public void selectsingleimage(HttpServletRequest request,HttpServletResponse response);
	public int selectemail(String email);
}
