package mvc.service;

import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Part;

import mvc.Dao.Daoinsert;
import mvc.Dao.Daoinsertinterface;
import mvc.Dao.Daoupdate;
import mvc.Dao.Daoupdateinterface;
import mvc.model.pojo_address;
import mvc.model.pojo_image;
import mvc.model.pojo_registration;
import mvc.util.securityalgo;

public class Serviceupdate implements Serviceupdateinterface {
	pojo_registration register = new pojo_registration();
	securityalgo algorithm = new securityalgo();
	Daoupdateinterface update= new Daoupdate();
	
	public void updateuserprofile(HttpServletRequest request) {
		// TODO Auto-generated method stub
		int id=(Integer)request.getAttribute("id");
		String addid1[]=request.getParameterValues("addid");
		int[] addid= new int[addid1.length];

		for(int i=0;i<addid.length;i++){
			addid[i]=Integer.parseInt(addid1[i]);
		}
		register.setFname(request.getParameter("fname"));
		register.setLname(request.getParameter("lname"));
		register.setGender(request.getParameter("gender"));
		register.setContact(request.getParameter("contact"));
		register.setDob(request.getParameter("dob"));
		register.setHobby_name(request.getParameter("hobby"));
		register.setLang_name(request.getParameter("lang"));
		register.setTech_name(request.getParameter("tech"));
		register.setRid(id);
		String[] address=request.getParameterValues("address");

		String[] city=request.getParameterValues("city");
		String[] state=request.getParameterValues("state");
		String[] country=request.getParameterValues("country");
		int no=address.length;
		pojo_address paddress[]= new pojo_address[no];
		System.out.println("add id is"+addid);
		for(int i=0;i<no;i++){
			paddress[i]=new pojo_address();
			paddress[i].setAddress(address[i]);
			paddress[i].setCity(city[i]);
			paddress[i].setState(state[i]);
			paddress[i].setCountry(country[i]);
			paddress[i].setAdd_id(addid[i]);

		}
		update.updateregisterdata(register);
		update.updateaddressdata(paddress);
	}

	public void update_password(int rid, String newpassword,
			HttpServletRequest request) {
		// TODO Auto-generated method stub
		register.setRid(rid);
		String newpassword1=algorithm.doDecryption(newpassword);
		register.setPassword(newpassword1);
		update.updatepassword(register);
	}

	public void forget_password(String email, String pass) {
		// TODO Auto-generated method stub
		register.setEmail(email);
		String newpassword=algorithm.doDecryption(pass);
		register.setPassword(newpassword);
		update.forgetpassword(register);
	}

	public void updateimage(String image_name, Part part, int image_id) {
		// TODO Auto-generated method stub
		try {
			pojo_image image = new pojo_image();
			image.setImage_name(image_name);
			InputStream input=null;
			input=part.getInputStream();
			image.setImage(input);
			image.setImage_id(image_id);
			update.update_image(image);
			
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
		
	}
	
}
