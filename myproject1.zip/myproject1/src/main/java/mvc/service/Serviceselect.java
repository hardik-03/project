package mvc.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.Dao.Daoselect;
import mvc.Dao.Daoselectinterface;
import mvc.model.pojo_address;
import mvc.model.pojo_image;
import mvc.model.pojo_registration;

public class Serviceselect implements Serviceselectinterface {
	pojo_registration register = new pojo_registration();
	Daoselectinterface select = new Daoselect();
	pojo_image image= new pojo_image();
	public pojo_registration selectsingleregdata(int rid){
		
		register.setRid(rid);
		
		select.singleuserregdata(register);
		return register;
		
	}

	public ArrayList<pojo_address> selectsingleadresdata(int rid) {
		// TODO Auto-generated method stub
		pojo_address address= new pojo_address();
		ArrayList<pojo_address> arraylist = new ArrayList<pojo_address>();
		
		arraylist=select.singleuseradresdata(rid);
		return arraylist;
	}

	public ArrayList<pojo_registration> alluserregdata() {
		// TODO Auto-generated method stub
		ArrayList<pojo_registration> arraylist = new ArrayList<pojo_registration>();		
		select.selectalluserregdata(arraylist);
		return arraylist;
	}

	public ArrayList<pojo_address> alluseradresdata() {
		// TODO Auto-generated method stub
		ArrayList arraylist = new ArrayList();
		select.selectalluseradresdata(arraylist);
		return arraylist;
	}
	
	public int selectuser_id(){
		return select.selectuserid();
	}

	public pojo_registration selectlogin(String email, String pass) {
		// TODO Auto-generated method stub
		ArrayList<pojo_registration> arraylist = new ArrayList<pojo_registration>();
		int role_id=0;
		register.setEmail(email);
		register.setPassword(pass);
		select.selectlogindata(register);
		return register;
	}

	public ArrayList<pojo_image> selectimagename(int user_id) {
		// TODO Auto-generated method stub
		ArrayList<pojo_image> arraylist = new ArrayList<pojo_image>();
		
		image.setUser_id(user_id);
		arraylist=select.selectallimagename(image);
		return arraylist;
	}

	public void selectsingleimage(HttpServletRequest request,HttpServletResponse response) {
		// TODO Auto-generated method stub
		byte bytearray[] = new byte[1048576];
		int image_id=(Integer)request.getAttribute("imageid");
		System.out.println("image id is on service select"+image_id);
		image.setImage_id(image_id);
		select.select_single_image(image,response);
	}

	public int selectemail(String email) {
		// TODO Auto-generated method stub
		int affectedrow=0;
//		register.setEmail("email");
		select.select_email(email);
		return select.select_email(email);
	}
}
