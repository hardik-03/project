package mvc.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Part;

import mvc.Dao.Daoinsert;
import mvc.Dao.Daoinsertinterface;
import mvc.model.pojo_address;
import mvc.model.pojo_image;
import mvc.model.pojo_registration;
import mvc.util.securityalgo;

public class Serviceinsert implements Serviceinsertinterface{
	
	Daoinsertinterface insert = new Daoinsert();
	public void insertregistration(ArrayList arraylist) {
		// TODO Auto-generated method stub
		pojo_registration register = new pojo_registration();
		securityalgo algorithm= new securityalgo();
		
		String fname = (String) arraylist.get(0);
		String lname = (String) arraylist.get(1);
		String gender = (String) arraylist.get(2);
		String contact = (String) arraylist.get(3);
		String dob = (String) arraylist.get(4);
		String email = (String) arraylist.get(5);
		String password = (String) arraylist.get(6);
		String hobby = (String) arraylist.get(7);
		String lang = (String) arraylist.get(8);
		int id = (Integer) arraylist.get(9);
		String tech = (String) arraylist.get(10);
		
		register.setFname(fname);
		register.setLname(lname);
		register.setGender(gender);
		register.setContact(contact);
		register.setDob(dob);
		register.setEmail(email);
		String pass=algorithm.doDecryption(password);
		register.setPassword(pass);
		register.setHobby_name(hobby);
		register.setLang_name(lang);
		register.setRole_id(id);
		register.setTech_name(tech);
		insert.insert_registration(register);

		
	}

	public void insertaddress(HttpServletRequest request) {
		// TODO Auto-generated method stub
		String[] address = request.getParameterValues("address");
		String[] city = request.getParameterValues("city");
		String[] state = request.getParameterValues("state") ;
		String[] country = request.getParameterValues("country");
		int rid=(Integer)request.getAttribute("rid");
		//int no=country.length;
		
		pojo_address paddress[]= new pojo_address[country.length];
		for(int i=0;i<country.length;i++){
		paddress[i]=new pojo_address();
		paddress[i].setAddress(address[i]);
		paddress[i].setCity(city[i]);
		paddress[i].setState(state[i]);
		paddress[i].setCountry(country[i]);
		paddress[i].setRid(rid);
		}
		insert.insert_address(paddress);
	}

	public void insertimage(String image_name, Part part,int user_id) {
		// TODO Auto-generated method stub
		try {
		pojo_image image = new pojo_image();
		image.setImage_name(image_name);
		InputStream input=null;
		input=part.getInputStream();
		image.setImage(input);
		image.setUser_id(user_id);
		Daoinsertinterface insert = new Daoinsert();
		insert.insert_image(image);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
	}

}
