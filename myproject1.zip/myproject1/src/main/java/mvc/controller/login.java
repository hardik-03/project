package mvc.controller;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import mvc.model.pojo_registration;
import mvc.service.Serviceselect;
import mvc.service.Serviceselectinterface;

/**
 * Servlet Filter implementation class login
 */
public class login implements Filter {

    /**
     * Default constructor. 
     */
    public login() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here

		// pass the request along the filter chain
		String email=request.getParameter("email");
		String pass=request.getParameter("pass");
		Serviceselectinterface select = new Serviceselect();
		pojo_registration register= new pojo_registration();
		register=select.selectlogin(email, pass);
		int role=register.getRole_id();
		int rid=register.getRid();
		HttpServletRequest req = (HttpServletRequest)request;
		HttpSession hs = req.getSession();
		hs.setAttribute("rid", rid);
		String path="";
		if(role==1){
			path="Header.jsp";
			//chain.doFilter(request, response);
		}
		else if(role==2){
			path="DHeader.jsp";
		}
		else{
			path="login.jsp";
			req.setAttribute("sms", "Email Id or Password invalid");
		}
		RequestDispatcher rd = request.getRequestDispatcher(path);
		rd.forward(request, response);
		
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
