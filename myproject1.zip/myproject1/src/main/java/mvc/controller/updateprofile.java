package mvc.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mvc.model.pojo_registration;
import mvc.service.Serviceselect;
import mvc.service.Serviceselectinterface;
import mvc.service.Serviceupdate;
import mvc.service.Serviceupdateinterface;

/**
 * Servlet implementation class updateprofile
 */
public class updateprofile extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public updateprofile() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String page=request.getParameter("page");
		int foreign_rid = 0;
		String path="";

		HttpSession hs = request.getSession();
		if(hs.getAttribute("rid")!=null){

			foreign_rid = (Integer) hs.getAttribute("rid");
			
			Serviceselectinterface select = new Serviceselect();
			request.setAttribute("address1", select.selectsingleadresdata(foreign_rid));
			request.setAttribute("data",select.selectsingleregdata(foreign_rid));
			pojo_registration register = new pojo_registration();
			String lang=register.getLang_name();
			if(page=="admin"){
				path="registrationforsample.jsp?page=admin";
			}
			else{
				request.setAttribute("profile", "Profile updated succesfully");
				path="registrationpageforsample.jsp?page=update&"+lang;
				//path="viewprofile";
			}
			RequestDispatcher rd = request.getRequestDispatcher(path);
			rd.forward(request, response);
			path="viewprofile";
			request.setAttribute("id", foreign_rid);
			Serviceupdateinterface update = new Serviceupdate();
			update.updateuserprofile(request);
			
		}
		else{
			RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
			rd.forward(request, response);
		}



	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
