package mvc.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mvc.model.pojo_address;
import mvc.model.pojo_registration;
import mvc.service.Serviceselect;
import mvc.service.Serviceselectinterface;

/**
 * Servlet implementation class viewprofile
 */
public class viewprofile extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public viewprofile() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession hs = request.getSession();
		if(hs.getAttribute("rid")!=null) {
			int rid=(Integer)hs.getAttribute("rid");
			Serviceselectinterface select = new Serviceselect();
			new pojo_registration();
			select.selectsingleregdata(rid);
			new pojo_address();
			new ArrayList<pojo_address>();

			select.selectsingleadresdata(rid);
			request.setAttribute("data",select.selectsingleregdata(rid));
			request.setAttribute("address1",select.selectsingleadresdata(rid));

			RequestDispatcher rd = request.getRequestDispatcher("viewuserprofile.jsp");
			rd.forward(request, response);
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
