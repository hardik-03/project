package mvc.controller;
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import mvc.service.Serviceinsert;
import mvc.service.Serviceinsertinterface;
import mvc.service.Serviceselect;
import mvc.service.Serviceselectinterface;
import mvc.util.securityalgo;

/**
 * Servlet implementation class registrationcontrol
 */
@MultipartConfig
public class registrationcontrol extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public registrationcontrol() {
        super();
        // TODO Auto-generated constructor stub
    }
    protected void processrequest(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException{
    	
    	String page1=request.getParameter("submit");
		String page=request.getParameter("page");
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String email=request.getParameter("email");
		String pass=request.getParameter("pass");
		String dob=request.getParameter("dob");
		String contact=request.getParameter("contact");
		String gender=request.getParameter("gender");
		String hobby=request.getParameter("hobby");
		String lang=request.getParameter("lang");
		String tech=request.getParameter("tech");
		String conpass=request.getParameter("conpass");
		String image_name=request.getParameter("iname");
		Part part = request.getPart("photo");
		String[] address=request.getParameterValues("address");
		String[] city=request.getParameterValues("city");
		String[] state = request.getParameterValues("state");
		String[] country=request.getParameterValues("country");
		int id=2;
		Serviceselectinterface select = new Serviceselect();
		int rid=select.selectuser_id();
		rid=rid+1;
		ArrayList arraylist = new ArrayList();
		String error="";
		String path="";
		int row=select.selectemail(email);
		if(fname.length()==0){
			error="Enter First Name";
			request.setAttribute("error1", error);
			path="registrationpageforsample.jsp?page=registration";
		}
		else if(lname.length()==0){
			error="Enter Last Name";
			request.setAttribute("error2", error);
			path="registrationpageforsample.jsp?page=registration";
		}
		else if(email.length()==0){
			error="Enter Email Address";
			request.setAttribute("error3", error);
			path="registrationpageforsample.jsp?page=registration";
		}
		else if(pass.length()==0 || conpass.length()==0){
			error="Enter password or confirm password";
			request.setAttribute("error4", error);
			path="registrationpageforsample.jsp?page=registration";
		}
		else if(dob.length()==0){
			error="Enter Date of Birth";
			request.setAttribute("error5", error);
			path="registrationpageforsample.jsp?page=registration";
		}
		else if(gender.length()==0){
			error="Select gender";
			request.setAttribute("error6", error);
			path="registrationpageforsample.jsp?page=registration";
		}
		else if(contact.length()==0){
			error="Enter contact number";
			request.setAttribute("error7", error);
			path="registrationpageforsample.jsp?page=registration";
		}
		else if(address.length==0){
			error="Enter address";
			request.setAttribute("error8", error);
			path="registrationpageforsample.jsp?page=registration";
		}
		else if(city.length==0){
			error="Enter city";
			request.setAttribute("error9", error);
			path="registrationpageforsample.jsp?page=registration";
		}
		else if(state.length==0){
			error="Enter State";
			request.setAttribute("error10", error);
			path="registrationpageforsample.jsp?page=registration";
		}
		else if(country.length==0){
			error="Enter Country";
			request.setAttribute("error11", error);
			path="registrationpageforsample.jsp?page=registration";
		}
		/*else if(conpass!=pass){
			error="Confirm password is not same as password";
			path="registrationpageforsample.jsp?page=registration";
		}*/
		else if(hobby.length()==0){
			error="Enter hobby";
			request.setAttribute("error12", error);
			path="registrationpageforsample.jsp?page=registration";
		}
		else if(row==1){
			error="Email id already exist";
			request.setAttribute("error3", error);
			path="registrationpageforsample.jsp?page=registration";
		}
		else if(image_name.length()==0){
			error="Enter name of image";
			request.setAttribute("error13", error);
			path="registrationpageforsample.jsp?page=registration";
		}
		else if(part.getSize()==0){
			error="Select image";
			request.setAttribute("error14", error);
			path="registrationpageforsample.jsp?page=registration";
		}
		else{
		path="login.jsp";
		securityalgo algorithm= new securityalgo();
		String password=algorithm.doEncryption(pass);
			arraylist.add(fname);
			arraylist.add(lname);
			arraylist.add(gender);
			arraylist.add(contact);
			arraylist.add(dob);
			arraylist.add(email);
			arraylist.add(password);
			arraylist.add(hobby);
			arraylist.add(lang);
			arraylist.add(id);
			arraylist.add(tech);
			request.setAttribute("rid", rid);
			Serviceinsertinterface insert = new Serviceinsert();
			insert.insertregistration(arraylist);
			insert.insertaddress(request);
			insert.insertimage(image_name, part,rid);
			request.setAttribute("login", "Registered Successfully! Now you can Login in our Website");
		}
			
			RequestDispatcher rd = request.getRequestDispatcher(path);
			rd.forward(request, response);
		
		
    
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		processrequest(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processrequest(request, response);
	}

}
