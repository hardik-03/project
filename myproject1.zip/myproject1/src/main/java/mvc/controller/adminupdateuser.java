package mvc.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mvc.service.Serviceselect;
import mvc.service.Serviceselectinterface;
import mvc.service.Serviceupdate;
import mvc.service.Serviceupdateinterface;


/**
 * Servlet implementation class adminupdateuser
 */
public class adminupdateuser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public adminupdateuser() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession hs = request.getSession();


		if(hs.getAttribute("rid")!=null){
			try{
				int id=Integer.parseInt(request.getParameter("id"));
				Serviceselectinterface select = new Serviceselect();
				request.setAttribute("data", select.selectsingleregdata(id));
				request.setAttribute("address1", select.selectsingleadresdata(id));
				request.setAttribute("user_id", id);
				RequestDispatcher rd = request.getRequestDispatcher("updateuser.jsp");
				rd.forward(request, response);
				request.getParameter("page");
				request.setAttribute("id", id);

				Serviceupdateinterface update = new Serviceupdate();
				update.updateuserprofile(request);
			}
			catch(Exception e){
				//e.printStackTrace();
				System.out.println(e.getMessage());
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
