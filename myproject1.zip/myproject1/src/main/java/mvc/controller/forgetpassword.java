package mvc.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.service.Serviceselect;
import mvc.service.Serviceselectinterface;
import mvc.service.Serviceupdate;
import mvc.service.Serviceupdateinterface;
import mvc.util.securityalgo;

/**
 * Servlet implementation class forgetpassword
 */
public class forgetpassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public forgetpassword() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
			securityalgo algorithm = new securityalgo();
			Serviceupdateinterface update= new Serviceupdate(); 
			String email=request.getParameter("email");
			String pass=request.getParameter("pass");
			String password=request.getParameter("pass1");
			Serviceselectinterface select = new Serviceselect();
			int row=select.selectemail(email);
			if(row==0){
				request.setAttribute("sms", "Enter valid email id");
			}
			else if(email.length()==0){
				request.setAttribute("error1", "Enter Email");
			}
			else if(pass.length()==0){
				request.setAttribute("error2", "Enter Password");
			}
			else if(password.length()==0){
				request.setAttribute("error3", "Enter Confirm Password");
			}
			else if(password.equals(pass)){
				String newpassword=algorithm.doEncryption(pass);
				update.forget_password(email, newpassword);
				request.setAttribute("update", "Password reset successfully");
			}
			else{
				String sms="New password and Confirm password must be same";
				request.setAttribute("message", sms);
			}
			RequestDispatcher rd = request.getRequestDispatcher("forgotpass.jsp");
			rd.forward(request, response);
			
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
