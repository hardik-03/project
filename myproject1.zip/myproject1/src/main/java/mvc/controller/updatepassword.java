package mvc.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mvc.service.Serviceupdate;
import mvc.service.Serviceupdateinterface;
import mvc.util.securityalgo;

/**
 * Servlet implementation class updatepassword
 */
public class updatepassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public updatepassword() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession hs = request.getSession();
		String page=request.getParameter("page");
		String path="";
		Serviceupdateinterface update = new Serviceupdate();
		securityalgo algorithm = new securityalgo();
		if(hs.getAttribute("rid")!=null){
			int rid=(Integer)hs.getAttribute("rid");
			String cur_pass =request.getParameter("cur_pass");
			String new_pass=request.getParameter("new_pass");
			if(new_pass.equals(cur_pass)) {
				String message="New password and old password can not be same";
				request.setAttribute("sms", "old and new password should not be same");
				if(page.equals("admin")){
					path="changepassword.jsp?page=admin";
				}
				else{
					path="changepassword.jsp?page=registration";
				}
				RequestDispatcher rd = request.getRequestDispatcher(path);
				rd.forward(request, response);
			}
			else if(cur_pass.length()==0){
				request.setAttribute("error", "Enter current Password");
				if(page.equals("admin")){
					path="changepassword.jsp?page=admin";
				}
				else{
					path="changepassword.jsp?page=registration";
				}
				RequestDispatcher rd = request.getRequestDispatcher(path);
				rd.forward(request, response);
			}
			else if(new_pass.length()==0){
				request.setAttribute("error1", "Enter New Password");
				if(page.equals("admin")){
					path="changepassword.jsp?page=admin";
				}
				else{
					path="changepassword.jsp?page=registration";
				}
				RequestDispatcher rd = request.getRequestDispatcher(path);
				rd.forward(request, response);
			}
			else {
			String newpassword=algorithm.doEncryption(new_pass);
			update.update_password(rid, newpassword, request);
			if(page.equals("admin")){
				path="changepassword.jsp?page=admin";
			}
			else{
				path="changepassword.jsp?page=registration";
			}
			request.setAttribute("update", "Password updated Successfully");
			RequestDispatcher rd = request.getRequestDispatcher(path);
			rd.forward(request, response);
			}
		}
		else{ 
			if(page=="forgetpassword"){
		String email=request.getParameter("email");
		String pass=request.getParameter("pass");
		String password=request.getParameter("pass1");
		if(password.equals(pass)){
			String newpassword=algorithm.doEncryption(pass);
			update.forget_password(email, newpassword);
		}
		else{
			String sms="New password and Confirm password must be same";
			request.setAttribute("message", sms);
		}
		RequestDispatcher rd = request.getRequestDispatcher("forgotpass.jsp");
		rd.forward(request, response);
		}
		else{
			RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
			rd.forward(request, response);
		}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
