package mvc.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mvc.service.Serviceinsert;
import mvc.service.Serviceinsertinterface;
import mvc.service.Serviceselect;
import mvc.service.Serviceselectinterface;
import mvc.service.Serviceupdate;
import mvc.service.Serviceupdateinterface;

/**
 * Servlet implementation class adminupdateprofile
 */
public class adminupdateprofile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public adminupdateprofile() {
        super();
        // TODO Auto-generated constructor stub
    }
    public void processrequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
    	HttpSession hs = request.getSession();
    	String path="";
    	try{
	    	if(hs.getAttribute("rid")!=null){
	    		path="adminprofile.jsp";
	    		int id = (Integer)(hs.getAttribute("rid"));
	    		Serviceselectinterface select = new Serviceselect();
	    		Serviceupdateinterface update = new Serviceupdate();
	    		request.setAttribute("data", select.selectsingleregdata(id));
				request.setAttribute("address1", select.selectsingleadresdata(id));
				RequestDispatcher rd = request.getRequestDispatcher("adminprofile.jsp");
				rd.forward(request, response);
				request.setAttribute("id",id);
				update.updateuserprofile(request);
	    	}
	    	else{
	    		
	    	}
    	}
    	catch(Exception e){
    		System.out.println(e.getMessage());
    	}
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processrequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processrequest(request, response);
	}

}
