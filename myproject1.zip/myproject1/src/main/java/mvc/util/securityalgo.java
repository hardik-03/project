package mvc.util;

public class securityalgo {
	 public static char p[]  = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i',
         'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
         'w', 'x', 'y', 'z','1','2','3','4','5','6','7','8','9','0'};
 public static char ch[] = { 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O',
         'P', 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Z', 'X', 'C',
         'V', 'B', 'N', 'M','0','5','1','9','2','7','3','6','4','8' };

 public  String doEncryption(String s)
 {
     char c[] = new char[(s.length())];
     for (int i = 0; i < s.length(); i++)
     {
         for (int j = 0; j < 36; j++)
         {
             if (p[j] == s.charAt(i))
             {
                 c[i] = ch[j];
                 break;
             }
         }
     }
     return (new String(c));
 }

 public  String doDecryption(String s)
 {
     char p1[] = new char[(s.length())];
     for (int i = 0; i < s.length(); i++)
     {
         for (int j = 0; j < 36; j++)
         {
             if (ch[j] == s.charAt(i))
             {
                 p1[i] = p[j];
                 break;
             }
         }
     }
     return (new String(p1));
 }

 
}
