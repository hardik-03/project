package mvc.util;

public class validation {
	
	public void registration(String fname,String lname,String dob,String contact,String email,String pass,String conpass,String address,String city,String state,String country,String error){
		if(fname.length()==0){
			error="Enter first name";
		}
		else if(lname.length()==0){
			error="Enter last name";
		}
		else if(dob.length()==0){
			error="Enter date of birth";
		}
		else if(contact.length()==0){
			error="Enter contact number";
		}
		else if(email.length()==0){
			error="Enter email id";
		}
		else if(pass.length()==0){
			error="Enter password";
		}
		else if(conpass.length()==0){
			error="Enter confirm password";
		}
		else if(address.length()==0){
			error="Enter address";
		}
		else if(city.length()==0){
			error="Enter city";
		}
		else if(state.length()==0){
			error="Enter State";
		}
		else if(country.length()==0){
			error="Enter Country";
		}
		else if(conpass!=pass){
			error="Confirm password is not same as password";
		}
	}
}
