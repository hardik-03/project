package mvc.util;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.model.pojo_sampleimage;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
/**
 * Servlet implementation class imageserv
 */

public class imageserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public imageserv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try{
			/*String message="";
			//String photo=request.getParameter("photo");
			//Part filepart=request.getPart("photo");
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sampledata","root","root");
			String query="insert into image values(?)";
			PreparedStatement psmt= con.prepareStatement(query);
			FileInputStream fin = new FileInputStream("g:\\1.jpg");
			psmt.setBlob(1,fin,fin.available());
			int i=psmt.executeUpdate();
			if(i>0){
				message="photo upload";
			}
			else{
				message="error";
			}
			request.setAttribute("sms", message);
			RequestDispatcher rd = request.getRequestDispatcher("images.jsp");
			rd.forward(request, response);
*/
			
//			RequestDispatcher rd = request.getRequestDispatcher(url);
//			rd.forward(request, response);
					
					
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	 private static final String BASE_UPLOAD_DIRECTORY = "F:\\sharingsmile";
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    DiskFileItemFactory factory = new DiskFileItemFactory();
        factory.setRepository(new File(System.getProperty("java.io.tmpdir")));
        ServletFileUpload upload = new ServletFileUpload(factory);
        String uploadPath = BASE_UPLOAD_DIRECTORY;
        pojo_sampleimage image = new pojo_sampleimage();
        List<FileItem> formItems = null;
		try {
			formItems = upload.parseRequest(request);
		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String path="";
        if (formItems != null && formItems.size() > 0) {
            // iterates over form's fields
            for (FileItem item : formItems) {
                // processes only fields that are not form fields
                if (!item.isFormField()) {
                   String  filePath = commonutil.UploadFile(item, uploadPath);
                   // image.setImg_name(filePath);
                   try{
                	   Class.forName("com.mysql.jdbc.Driver");
                     	 Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sampledata","root","root");
                     	 PreparedStatement psmt = con.prepareStatement("insert into image(img_name) value(?)");
                     	 psmt.setString(1, filePath);
                     	 psmt.executeUpdate();
                   }
                   catch(Exception e){
                	   System.out.println(e.getMessage());
                   }
                    path=image.getImg_name();
                    System.out.println("path is"+path);
                    request.setAttribute("filePath",
                            "Upload Path : " + filePath);
                    request.setAttribute("message",
                            "Upload has been done Successfully!!!");
                } 
                }
            }
       /* try{
       	 Class.forName("com.mysql.jdbc.Driver");
       	 Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sampledata","root","root");
       	 PreparedStatement psmt = con.prepareStatement("insert into image value(?)");
       	 psmt.setString(1, path);
       	 psmt.executeUpdate();
       	 request.setAttribute("sms", "image uploaded");
       	 RequestDispatcher rd = request.getRequestDispatcher("images.jsp");
       	 rd.forward(request, response);
        
        }catch(Exception e){
       	 
        }
*/        }
}
     
	
	


