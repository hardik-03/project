package mvc.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class displayimage
 */
public class displayimage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public displayimage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		 InputStream sImage;
		 try{
	            Class.forName("com.mysql.jdbc.Driver");
	         Connection   conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/registration", "root","root");
	       //     PreparedStatement stmt = conn.prepareStatement("select img_name from image where imgid='"+6+"'");
	         Statement stmt = conn.createStatement();   
	            ResultSet rs = stmt.executeQuery("select registration.image_name from image");
	          /*  while(rs.next()){
	            	byte[] bytearray= new byte[1048576];
	            	int size=0;
	            	sImage = rs.getBinaryStream("img_name");
	            	response.reset();
	            	response.setContentType("image/jpeg");
	            	while((size=sImage.read(bytearray))!=-1){
	            		response.getOutputStream().write(bytearray,0,size);
	            	}
	            	RequestDispatcher rd = request.getRequestDispatcher("imagedisplay.jsp");
	            	rd.forward(request, response);	
	            }
*/	            String name="";
				//ArrayList ar = new ArrayList();
	            while(rs.next()){
	            	name=rs.getString("image_name");
	            //	ar.add(name);
				}
	            request.setAttribute("name1", name);
	            RequestDispatcher rd = request.getRequestDispatcher("imagedisplay.jsp");
	            rd.forward(request, response);

	        } catch (Exception e){
	            e.printStackTrace();
	            System.out.println(e.getMessage());
	        }

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
			}

}
