package mvc.util;

import java.io.File;

import org.apache.commons.fileupload.FileItem;

public class commonutil {
	 public static String UploadFile(FileItem file, String fileUploadPath) {
	        try {
	            // Creating the directory to store file
	            File dir = new File(fileUploadPath);
	            if (!dir.exists()) {
	                dir.mkdirs();
	            }
	            String fileName = new File(file.getName()).getName();
	            String filePath = fileUploadPath + File.separator + fileName;
	            File storeFile = new File(filePath);
	            // saves the file on disk
	            file.write(storeFile);
	            System.out.println("**********"+filePath);
	            return filePath;
	        } catch (Exception e) {
	            System.out.println("File Upload Exception : " + e.getMessage());
	            return "-1";
	        }
	 }
}
