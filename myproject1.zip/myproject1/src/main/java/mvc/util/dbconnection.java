package mvc.util;



import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;
public class dbconnection {
	/**
	 * Logger for this class
	 */
	

	public static Properties dbconnections() throws IOException {
		

		Properties prop = new Properties();
		InputStream path= dbconnection.class.getResourceAsStream("/dbconnection.properties");
		BufferedReader br = new BufferedReader(new InputStreamReader(path));
		if(br!=null) {
		prop.load(br);
		} 

		
		return prop;
		
	}
	
	public String driverconnection() throws IOException {
		

		Properties prop = dbconnections();
		String driver=prop.getProperty("driver");

		
		return driver;
	}
	public String connectionurl() throws IOException
	{
		

		Properties prop = dbconnections();
		String url=prop.getProperty("url");
		
		
		
		return url;
		
	}
	public String connectionuser() throws IOException {
		
		
		Properties prop = dbconnections();
		String user=prop.getProperty("username");

		
		return user;
	}
	public String connectionpass() throws IOException {
		

		Properties prop = dbconnections();
		String pass=prop.getProperty("password");

		
		return pass;
	}
}


