package mvc.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class displayphoto
 */
public class displayphoto extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public displayphoto() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sampledata","root","root");
			PreparedStatement ps = con.prepareStatement("select image from image where name=?");
			String name=request.getParameter("name");
			ps.setString(1, name);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				  Blob b = rs.getBlob("image");
		            response.setContentType("image/jpeg");
		            response.setContentLength((int) b.length());
		            InputStream is = b.getBinaryStream();
		            OutputStream os = response.getOutputStream();
		            byte buf[] = new byte[(int) b.length()];
		            is.read(buf);
		            os.write(buf);
		            os.close();
			}
		
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
