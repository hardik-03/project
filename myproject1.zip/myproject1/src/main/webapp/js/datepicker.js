 $(function() {
    $( "#date_ex" ).datepicker();
  });